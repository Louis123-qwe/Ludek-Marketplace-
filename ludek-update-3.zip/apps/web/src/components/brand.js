import { esc } from '../lib/dom.js';
import { BRAND } from '../config.js';

const petal = (rotation, color) =>
  `<path d="M53 47V30A24 24 0 0 1 77 6H94V23A24 24 0 0 1 70 47Z" fill="${color}" transform="rotate(${rotation} 50 50)"/>`;

export function logoMark(size = 40, dark = false) {
  const colors = dark ? ['#FAF7F0', '#C8DFB0', '#8FBF5A', '#6BA33A'] : ['#1E3810', '#2D5016', '#4E8426', '#8FBF5A'];
  const ring = dark ? '#2D5016' : '#FAF7F0';
  const disc = dark ? '#FAF7F0' : '#2D5016';
  const letter = dark ? '#2D5016' : '#FAF7F0';
  return `<svg width="${size}" height="${size}" viewBox="0 0 100 100" role="img" aria-label="${esc(BRAND.name)}">${petal(0, colors[0])}${petal(90, colors[1])}${petal(180, colors[2])}${petal(270, colors[3])}<circle cx="50" cy="50" r="22" fill="${ring}"/><circle cx="50" cy="50" r="19.5" fill="${disc}"/><path d="M41 38H48.5V54.8H57.5L60.8 58.4L57.5 62H41Z" fill="${letter}" transform="translate(50 50) scale(1.12) translate(-50 -50)"/></svg>`;
}

export const wordmark = (size = 20, sub = true) =>
  `<span class="wm"><b style="font-size:${size}px">Ludek<i> Market</i></b>${sub ? `<small>${esc(BRAND.campus)}</small>` : ''}</span>`;
